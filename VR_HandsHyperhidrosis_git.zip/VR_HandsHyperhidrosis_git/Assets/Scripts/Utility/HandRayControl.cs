using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class HandRayControl : MonoBehaviour
{
    [SerializeField] private XRRayInteractor leftRayInteractor;   
    [SerializeField] private XRRayInteractor rightRayInteractor;   
    [SerializeField] private XRInteractorLineVisual leftHandRayVisual;
    [SerializeField] private XRInteractorLineVisual rightHandRayVisual;
    [SerializeField] private bool[] lineModesVisibility;
    [SerializeField] private float[] lineModesLenght;

    int leftState = 0;
    bool leftDebounce = false;
    int rightState = 0;
    bool rightDebounce = false;
    int NlineModes;
    // Start is called before the first frame update
    void Start()
    {
        leftState = 0;
        leftDebounce = false;
        rightState = 0;
        rightDebounce = false;

        NlineModes = lineModesLenght.Length <= lineModesVisibility.Length ? lineModesLenght.Length : lineModesVisibility.Length;

        updateLeft();
        updateRight();
    }

    // Update is called once per frame
    void Update()
    {
        bool left, right;
        HandleControllers.checkButtonsPress(out left, out right);

        if(left && (!leftDebounce))
        {
            leftDebounce = true;
            leftState = (leftState + 1) % NlineModes;
            updateLeft();
        }
        if ((!left) && leftDebounce)
        {
            leftDebounce = false;
        }

        if (right && (!rightDebounce))
        {
            rightDebounce = true;
            rightState = (rightState + 1) % NlineModes;
            updateRight();
        }
        if ((!right) && rightDebounce)
        {
            rightDebounce = false;
        }
    }

    private void updateRight()
    {
        rightHandRayVisual.enabled = lineModesVisibility[rightState];
        rightRayInteractor.maxRaycastDistance = lineModesLenght[rightState];
    }

    private void updateLeft()
    {
        leftHandRayVisual.enabled = lineModesVisibility[leftState];
        leftRayInteractor.maxRaycastDistance = lineModesLenght[leftState];
    }
}
