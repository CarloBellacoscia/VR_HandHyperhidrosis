using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainLogic : MonoBehaviour
{
    [SerializeField] private Transform RightHandTransform;
    [SerializeField] private Transform LeftHandTransform;

    // Start is called before the first frame update
    void Start()
    {
        HandleControllers.setHands(LeftHandTransform, RightHandTransform);

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
