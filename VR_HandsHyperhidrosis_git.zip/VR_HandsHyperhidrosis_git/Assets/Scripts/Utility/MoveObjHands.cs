using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;

public class MoveObjHands : MonoBehaviour
{
    [SerializeField] private Transform RightController;
    [SerializeField] private Transform LeftController;
    [SerializeField] private float SceneTransSpeed;
    [SerializeField] private float SceneRotSpeed;

    private GameObject rightInstrument;
    private GameObject leftInstrument;
    private GameObject rightHand;
    private GameObject leftHand;

    private Vector3 rightInstrumentRot;
    //private Vector3 rightInstrumentPos;
    private Vector3 leftInstrumentRot;
    //private Vector3 leftInstrumentPos;

    private Vector3 rightHandRot;
    //private Vector3 rightHandPos;
    private Vector3 leftHandRot;
    //private Vector3 leftHandPos;

    bool leftPrimaryPress = false;
    bool leftSecondaryPress = false;
    bool rightPrimaryPress = false;
    bool rightSecondaryPress = false;

    bool activeLeft = false;
    bool activeRight = false;


    // Start is called before the first frame update
    void Start()
    {
        rightInstrument = RightController.GetChild(0).transform.GetChild(0).transform.GetChild(1).gameObject;
        leftInstrument = LeftController.GetChild(0).transform.GetChild(0).transform.GetChild(1).gameObject;

        rightHand = RightController.GetChild(0).transform.GetChild(0).transform.GetChild(0).gameObject;
        leftHand = LeftController.GetChild(0).transform.GetChild(0).transform.GetChild(0).gameObject;

        //rightInstrumentRot = rightInstrument.transform.rotation.eulerAngles;
        //leftInstrumentRot = leftInstrument.transform.rotation.eulerAngles;
        //rightInstrumentPos = rightInstrument.transform.position;
        //leftInstrumentPos = leftInstrument.transform.position;

    }

    // Update is called once per frame
    void Update()
    {
        //rightHand = RightController.GetChild(0).transform.GetChild(0).transform.GetChild(0).gameObject;
        //leftHand = LeftController.GetChild(0).transform.GetChild(0).transform.GetChild(0).gameObject;

        if (rightInstrument.transform.childCount > 0 || leftInstrument.transform.childCount > 0) 
        { 
            this.GetComponent<HandRayControl>().enabled = false;
            checkButton(out leftPrimaryPress, out leftSecondaryPress, out rightPrimaryPress, out rightSecondaryPress);
            
            if (rightInstrument.transform.childCount > 0)
            {
                if (!activeRight)
                {
                    rightInstrumentRot = rightInstrument.transform.GetChild(0).transform.rotation.eulerAngles;
                    //rightInstrumentPos = rightInstrument.transform.GetChild(0).transform.position;

                    rightHandRot = rightHand.transform.rotation.eulerAngles;
                    //rightHandPos = rightHand.transform.position;

                    activeRight = true;
                }
                if (Keyboard.current.leftArrowKey.wasPressedThisFrame || rightPrimaryPress)
                {
                    //rightInstrument.transform.GetChild(0).transform.Rotate(0.0f, 90.0f, 0.0f, Space.Self);
                    rightInstrument.transform.GetChild(0).transform.Rotate(new Vector3(0.0f, 0.0f, 45.0f) * Time.deltaTime * SceneRotSpeed, Space.Self);
                    //rightHand.transform.Rotate(new Vector3(0.0f, -45.0f, 0.0f) * Time.deltaTime * SceneRotSpeed, Space.Self);
                }
                else if (Keyboard.current.upArrowKey.wasPressedThisFrame || rightSecondaryPress)
                {
                    //rightInstrument.transform.GetChild(0).transform.Rotate(90.0f, 0.0f, 0.0f, Space.Self);
                    //rightInstrument.transform.GetChild(0).transform.Rotate(new Vector3(45.0f, 0.0f, 0.0f) * Time.deltaTime * SceneRotSpeed, Space.Self);
                    //rightHand.transform.Rotate(new Vector3(45.0f, 0.0f, 0.0f) * Time.deltaTime * SceneRotSpeed, Space.Self);
                    rightInstrument.transform.GetChild(0).transform.Rotate(new Vector3(0.0f, 180.0f, 0.0f));
                }
            }
            if (leftInstrument.transform.childCount > 0)
            {
                if (!activeLeft)
                {
                    leftInstrumentRot = leftInstrument.transform.GetChild(0).transform.rotation.eulerAngles;
                    //leftInstrumentPos = leftInstrument.transform.GetChild(0).transform.position;

                    leftHandRot = leftHand.transform.rotation.eulerAngles;
                    //leftHandPos = leftHand.transform.position;

                    activeLeft = true;
                }
                if (Keyboard.current.leftArrowKey.wasPressedThisFrame || leftPrimaryPress)
                {
                    //leftInstrument.transform.GetChild(0).transform.Rotate(0.0f, 90.0f, 0.0f, Space.Self);
                    leftInstrument.transform.GetChild(0).transform.Rotate(new Vector3(0.0f, 0.0f, 45.0f) * Time.deltaTime * SceneRotSpeed, Space.Self);
                    //leftHand.transform.Rotate(new Vector3(0.0f, -45.0f, 0.0f) * Time.deltaTime * SceneRotSpeed, Space.Self);
                }
                else if (Keyboard.current.upArrowKey.wasPressedThisFrame || leftSecondaryPress)
                {
                    //leftInstrument.transform.GetChild(0).transform.Rotate(90.0f, 0.0f, 0.0f, Space.Self);
                    //leftInstrument.transform.GetChild(0).transform.Rotate(new Vector3(45.0f, 0.0f, 0.0f) * Time.deltaTime * SceneRotSpeed, Space.Self);
                    //leftHand.transform.Rotate(new Vector3(45.0f, 0.0f, 0.0f) * Time.deltaTime * SceneRotSpeed, Space.Self);
                    rightInstrument.transform.GetChild(0).transform.Rotate(new Vector3(0.0f, 180.0f, 0.0f));
                }
            }

        }

        /*if (Right_Obj.childCount > 0 || Left_Obj.childCount > 0)
        {
                Vector4 thumbs = HandleControllers.getThumbSticksDir();

            float deltaAng = Mathf.Deg2Rad * Vector3.SignedAngle(new Vector3(0, 0, 1), Right_Obj.forward, new Vector3(0, 1, 0));

            Vector3 dir = new Vector3(-thumbs.w * Mathf.Sin(deltaAng) - thumbs.z * Mathf.Cos(deltaAng),
                                      //-thumbs.y,
                                      0,
                                       thumbs.z * Mathf.Sin(deltaAng) - thumbs.w * Mathf.Cos(deltaAng));
            Root_Obj.Translate(dir * SceneTransSpeed * Time.deltaTime);

            Right_Obj.RotateAround(Right_Obj.position, new Vector3(0, 1, 0), thumbs.x * SceneRotSpeed * Time.deltaTime);
            Right_Obj.RotateAround(Right_Obj.position, new Vector3(1, 0, 0), thumbs.y * SceneRotSpeed * Time.deltaTime);
            Right_Obj.RotateAround(Right_Obj.position, new Vector3(0, 0, 1), thumbs.z * SceneRotSpeed * Time.deltaTime);

            Left_Obj.RotateAround(Right_Obj.position, new Vector3(0, 1, 0), thumbs.x * SceneRotSpeed * Time.deltaTime);
            Left_Obj.RotateAround(Right_Obj.position, new Vector3(1, 0, 0), thumbs.y * SceneRotSpeed * Time.deltaTime);
            Left_Obj.RotateAround(Right_Obj.position, new Vector3(0, 0, 1), thumbs.z * SceneRotSpeed * Time.deltaTime);*/

        //        Debug.Log(Root_Camera.position + " " + Root_Scene.eulerAngles);
    }
    private void checkButton(out bool leftPrimaryPress, out bool leftSecondaryPress, out bool rightPrimaryPress, out bool rightSecondaryPress)
    {
        UnityEngine.XR.InputDevice leftDevice;
        UnityEngine.XR.InputDevice rightDevice;

        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                leftPrimaryPress = primaryButtonValue;
                leftSecondaryPress = secondaryButtonValue;
            }
            else
            {
                leftPrimaryPress = false;
                leftSecondaryPress = false;
            }
        }
        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                rightPrimaryPress = primaryButtonValue;
                rightSecondaryPress = secondaryButtonValue;
            }
            else
            {
                rightPrimaryPress = false;
                rightSecondaryPress = false;
            }

        }
    }

    public void ResetInstruments()
    {
        if (rightInstrument.transform.childCount > 0 || leftInstrument.transform.childCount > 0)
        {
            if (activeLeft && leftInstrument.transform.childCount > 0 && leftInstrument.transform.GetChild(0).transform.rotation != Quaternion.Euler(new Vector3(0, 0, 0)))
            {
                leftInstrument.transform.GetChild(0).transform.rotation = Quaternion.Euler(leftInstrumentRot);
                //leftInstrument.transform.GetChild(0).transform.position = leftInstrumentPos;

                //leftHand.transform.rotation = Quaternion.Euler(leftHandRot);
                //leftHand.transform.position = leftHandPos;

                activeLeft = false;
            }
            if(activeRight && rightInstrument.transform.childCount > 0 && rightInstrument.transform.GetChild(0).transform.rotation != Quaternion.Euler(new Vector3(0, 0, 0)))
            {
                rightInstrument.transform.GetChild(0).transform.rotation = Quaternion.Euler(rightInstrumentRot);
                //rightInstrument.transform.GetChild(0).transform.position = rightInstrumentPos;

                //rightHand.transform.rotation = Quaternion.Euler(rightHandRot);
                //rightHand.transform.position = rightHandPos;

                activeRight = false;
            }
        }
    }

    public void AlignInstruments() 
    {

        if (rightInstrument.transform.childCount > 0 || leftInstrument.transform.childCount > 0)
        {
            if (activeLeft && leftInstrument.transform.childCount > 0)
            {
                //Debug.Log("Aligning Left Instrument");
                //leftInstrument.transform.GetChild(0).transform.rotation = leftHand.transform.rotation;
                leftInstrument.transform.GetChild(0).transform.localEulerAngles = new Vector3(0, 0, 0);
                leftInstrument.transform.GetChild(0).transform.GetChild(0).transform.localEulerAngles = new Vector3(0, 0, 0);

                activeLeft = false;
            }
            if (activeRight && rightInstrument.transform.childCount > 0)
            {
                //Debug.Log("Aligning Right Instrument");
                //rightInstrument.transform.GetChild(0).transform.rotation = rightHand.transform.rotation;
                rightInstrument.transform.GetChild(0).transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));
                rightInstrument.transform.GetChild(0).transform.GetChild(0).transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0));

                activeRight = false;
            }
        }
    }
}
