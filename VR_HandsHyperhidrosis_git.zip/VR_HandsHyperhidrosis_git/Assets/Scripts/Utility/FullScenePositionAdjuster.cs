using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FullScenePositionAdjuster : MonoBehaviour
{
    [SerializeField] private Transform Root_Scene;
    [SerializeField] private Transform Root_Camera;
    [SerializeField] private float SceneTransSpeed;
    [SerializeField] private float SceneRotSpeed;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector4 thumbs = HandleControllers.getThumbSticksDir();
        float deltaAng = Mathf.Deg2Rad * Vector3.SignedAngle(new Vector3(0, 0, 1), Root_Camera.forward, new Vector3(0, 1, 0));

        Vector3 dir = new Vector3(-thumbs.w * Mathf.Sin(deltaAng) - thumbs.z * Mathf.Cos(deltaAng),
                                  -thumbs.y,
                                   thumbs.z * Mathf.Sin(deltaAng) - thumbs.w * Mathf.Cos(deltaAng));
        Root_Scene.Translate(-dir * SceneTransSpeed * Time.deltaTime);


        Root_Scene.RotateAround(Root_Camera.position, new Vector3(0, 1, 0), thumbs.x * SceneRotSpeed * Time.deltaTime);
//        Debug.Log(Root_Camera.position + " " + Root_Scene.eulerAngles);
    }
}
