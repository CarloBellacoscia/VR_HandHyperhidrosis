using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeManager : MonoBehaviour
{
    [SerializeField] GameObject laparoscopeHole = null; 
    public static Action OnSecondChanged;
    public static Action OnMinuteChanged;

    public static int Second { get; private set; }
    public static int Minute { get; private set; }

    private float secondToRealTime = 1.0f;
    private float timer;

    private bool active = false;

    public int stepCounter = 0;

    // Start is called before the first frame update
    void Start()
    {
        Second = 0;
        Minute = 0;
        timer = secondToRealTime;
    }

    // Update is called once per frame
    void Update()
    {
        if (active) { 
            timer -= Time.deltaTime;

            if (timer <= 0)
            {
                timer = secondToRealTime;
                Second++;
                OnSecondChanged?.Invoke();

                if (Second >= 60)
                {
                    Second = 0;
                    Minute++;
                    OnMinuteChanged?.Invoke();
                }
            }
        }
    }

    public void StartTimer()
    {
        active = true;
    }
    public void StopTimer()
    {
        if (stepCounter < 1)
        {
            stepCounter++;
            return;
        }
        else
        {
            active = false;
            if (laparoscopeHole != null && laparoscopeHole.transform.childCount > 0)
            {
                laparoscopeHole.GetComponent<CapsuleCollider>().enabled = false;
                laparoscopeHole.transform.GetChild(0).transform.GetChild(0).GetComponent<CapsuleCollider>().enabled = true;
            }
        }
    }
}
