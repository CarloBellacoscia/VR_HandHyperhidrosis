using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;

public class MoveLaparoscope : MonoBehaviour
{

    private GameObject laparoscope; 
    [SerializeField] private float laparoscopeSpeed = 0.1f;

    private Vector3 laparoscopeRot;

    bool reset = false;

    bool leftPrimaryPress = false;
    bool rightPrimaryPress = false;

    // Start is called before the first frame update
    void Start()
    {
        laparoscope = GameObject.Find("Scene/Laparoscope_hole");
        laparoscopeRot = laparoscope.transform.rotation.eulerAngles;
    }

    // Update is called once per frame
    void Update()
    {
        if(laparoscope.transform.childCount > 0)
        {
            //Debug.Log(laparoscope.name);
            checkButton(out leftPrimaryPress, out rightPrimaryPress);

            if (Keyboard.current.mKey.wasPressedThisFrame || rightPrimaryPress)
            {
                //Debug.Log(laparoscope.name);
                laparoscope.transform.Rotate(new Vector3(0.0f, 5.0f, 0.0f) * laparoscopeSpeed, Space.Self);

            }
            if (Keyboard.current.nKey.wasPressedThisFrame || leftPrimaryPress)
            {
                laparoscope.transform.Rotate(new Vector3(0.0f, -5.0f, 0.0f) * laparoscopeSpeed, Space.Self);

            }

            reset = true;
        }
        else if(reset)
        {             
            laparoscope.transform.rotation = Quaternion.Euler(laparoscopeRot);
            reset = false;
        }
    }

    private void checkButton(out bool leftPrimaryPress, out bool rightPrimaryPress)
    {
        UnityEngine.XR.InputDevice leftDevice;
        UnityEngine.XR.InputDevice rightDevice;

        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                leftPrimaryPress = primaryButtonValue;
                //leftSecondaryPress = secondaryButtonValue;
            }
            else
            {
                leftPrimaryPress = false;
                //leftSecondaryPress = false;
            }
        }
        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                rightPrimaryPress = primaryButtonValue;
                //rightSecondaryPress = secondaryButtonValue;
            }
            else
            {
                rightPrimaryPress = false;
                //rightSecondaryPress = false;
            }

        }
    }
}
