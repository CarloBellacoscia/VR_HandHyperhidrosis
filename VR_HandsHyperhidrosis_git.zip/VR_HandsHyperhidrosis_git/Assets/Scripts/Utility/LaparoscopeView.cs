using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class LaparoscopeView : MonoBehaviour
{
    [SerializeField] private GameObject RightHandController;
    [SerializeField] private GameObject LeftHandController;

    [SerializeField] private GameObject GameController;

    private GameObject RightHand = null;
    private GameObject ParentRightHand = null;
    private GameObject LeftHand = null;
    private GameObject ParentLeftHand = null;

    private float RightHand_z = 0.0f;
    private float LeftHand_z = 0.0f;

    private bool active = false;

    bool leftPrimaryPress = false;
    bool leftSecondaryPress = false;
    bool rightPrimaryPress = false;
    bool rightSecondaryPress = false;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        RightHand = RightHandController.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject;
        ParentRightHand = RightHandController.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.transform.GetChild(1).gameObject;
        LeftHand = LeftHandController.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject;
        ParentLeftHand = LeftHandController.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.transform.GetChild(1).gameObject;

        checkButton(out leftPrimaryPress, out leftSecondaryPress, out rightPrimaryPress, out rightSecondaryPress);

        if (active) 
        { 
            if ((rightPrimaryPress || Keyboard.current.gKey.isPressed))
            {
                Debug.Log((RightHand.transform.position.z - RightHand_z) * 300);
                this.transform.Rotate(new Vector3(0.0f, (RightHand.transform.position.z - RightHand_z) * -300), Space.Self);
                RightHand_z = RightHand.transform.position.z;
            }
            else if ((leftPrimaryPress || Keyboard.current.fKey.isPressed))
            {
                Debug.Log((LeftHand.transform.position.z - LeftHand_z) * 300);
                this.transform.Rotate(new Vector3(0.0f, (LeftHand.transform.position.z - LeftHand_z) * -300), Space.Self);
                LeftHand_z = LeftHand.transform.position.z;
            }
            else
            {
                active = false;
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.name.Equals(RightHand.name) && RightHand.activeSelf == true /*&& (rightPrimaryPress || Keyboard.current.gKey.isPressed)*/)
        {
            RightHand_z = RightHand.transform.position.z;
        }
        else if (other.name.Equals(LeftHand.name) && LeftHand.activeSelf == true /*&& (leftPrimaryPress || Keyboard.current.fKey.isPressed)*/)
        {
            LeftHand_z = LeftHand.transform.position.z;
        }
    }

    private void OnTriggerExit(Collider other) 
    {
        active = false;
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.name.Equals(RightHand.name) && RightHand.activeSelf == true && (rightPrimaryPress || Keyboard.current.gKey.isPressed))
        {
            Debug.Log((RightHand.transform.position.z - RightHand_z) * 300);
            this.transform.Rotate(new Vector3(0.0f, (RightHand.transform.position.z - RightHand_z) * -330), Space.Self);
            RightHand_z = RightHand.transform.position.z;
        }
        else if (other.name.Equals(LeftHand.name) && LeftHand.activeSelf == true && (leftPrimaryPress || Keyboard.current.fKey.isPressed))
        {
            Debug.Log((LeftHand.transform.position.z - LeftHand_z) * 300);
            this.transform.Rotate(new Vector3(0.0f, (LeftHand.transform.position.z - LeftHand_z) * -330), Space.Self);
            LeftHand_z = LeftHand.transform.position.z;
        }
    }

    private void checkButton(out bool leftPrimaryPress, out bool leftSecondaryPress, out bool rightPrimaryPress, out bool rightSecondaryPress)
    {
        UnityEngine.XR.InputDevice leftDevice;
        UnityEngine.XR.InputDevice rightDevice;

        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                leftPrimaryPress = primaryButtonValue;
                leftSecondaryPress = secondaryButtonValue;
            }
            else
            {
                leftPrimaryPress = false;
                leftSecondaryPress = false;
            }
        }
        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                rightPrimaryPress = primaryButtonValue;
                rightSecondaryPress = secondaryButtonValue;
            }
            else
            {
                rightPrimaryPress = false;
                rightSecondaryPress = false;
            }

        }
    }
}
