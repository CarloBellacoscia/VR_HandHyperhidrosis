using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ErrorManager : MonoBehaviour
{
    public TextMeshProUGUI errorText;
    private int errors = 0;
    private int warningCount = 0;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        errorText.text = $"Errors: {errors:00}";
    }

    public void AddError()
    {
        errors++;
    }

    public void RemoveError()
    {
        errors--;
    }

    public void ResetErrors()
    {
        errors = 0;
    }

    public void AddWarning()
    {
        if(warningCount < 3)
        {
            warningCount++;
        }
        else
        {
            warningCount = 0;
            AddError();
        }
    }
}
