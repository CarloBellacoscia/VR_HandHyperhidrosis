using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchParents : MonoBehaviour
{
    [SerializeField] private GameObject ParentRightHand;
    [SerializeField] private GameObject ParentLeftHand;

    private void OnTriggerEnter(Collider other)
    {
        if (other.name.Equals("RightHand"))
        {
            this.transform.SetParent(ParentRightHand.transform);
        }
        else if (other.name.Equals("LeftHand"))
        {
            this.transform.SetParent(ParentLeftHand.transform);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
