using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

public class HandleControllers 
{
    private static Transform RightHandTransform;
    private static Transform LeftHandTransform;

    public static void setHands(Transform left, Transform right)
    {
        LeftHandTransform = left;
        RightHandTransform = right;
    }

    public static bool checkAtLeastOnePress(out bool isRightHand)
    {
        bool atLeastOnePressInObject = false;
        bool leftPress;
        bool rightPress;
        InputDevice leftDevice;
        InputDevice rightDevice;

        {
            List<InputDevice> devices = new List<InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                leftDevice.TryGetFeatureValue(CommonUsages.triggerButton, out bool triggerButtonValue);
                leftDevice.TryGetFeatureValue(CommonUsages.gripButton, out bool gripButtonValue);
                leftPress = triggerButtonValue || gripButtonValue;
            }
            else
            {
                leftPress = false;
            }
        }
        {
            List<InputDevice> devices = new List<InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                rightDevice.TryGetFeatureValue(CommonUsages.triggerButton, out bool triggerButtonValue);
                rightDevice.TryGetFeatureValue(CommonUsages.gripButton, out bool gripButtonValue);
                rightPress = triggerButtonValue || gripButtonValue;
            }
            else
            {
                rightPress = false;
            }

        }

        atLeastOnePressInObject = leftPress | rightPress;
        isRightHand = rightPress;

        return atLeastOnePressInObject;
    }
    public static Transform getMainHandTransform(bool isRightHand)
    {
        if (isRightHand)
        {
            return RightHandTransform;
        }
        else
        {
            return LeftHandTransform;
        }
    }
    public static Vector4 getThumbSticksDir()
    {
        InputDevice leftDevice;
        InputDevice rightDevice;
        Vector2 lts = new Vector2();
        Vector2 rts = new Vector2();

        {
            List<InputDevice> devices = new List<InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                leftDevice.TryGetFeatureValue(CommonUsages.primary2DAxis, out lts);
            }
        }
        {
            List<InputDevice> devices = new List<InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                rightDevice.TryGetFeatureValue(CommonUsages.primary2DAxis, out rts);
            }
        }

        return new Vector4(lts.x, lts.y, rts.x, rts.y);

    }
    public static void checkButtonsPress(out bool leftPress, out bool rightPress)
    {
        InputDevice leftDevice;
        InputDevice rightDevice;

        {
            List<InputDevice> devices = new List<InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                leftDevice.TryGetFeatureValue(CommonUsages.primaryButton, out bool primaryButtonValue);
                leftDevice.TryGetFeatureValue(CommonUsages.secondaryButton, out bool secondaryButtonValue);
                leftPress = primaryButtonValue || secondaryButtonValue;
            }
            else
            {
                leftPress = false;
            }
        }
        {
            List<InputDevice> devices = new List<InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                rightDevice.TryGetFeatureValue(CommonUsages.primaryButton, out bool primaryButtonValue);
                rightDevice.TryGetFeatureValue(CommonUsages.secondaryButton, out bool secondaryButtonValue);
                rightPress = primaryButtonValue || secondaryButtonValue;
            }
            else
            {
                rightPress = false;
            }

        }
    }
}
