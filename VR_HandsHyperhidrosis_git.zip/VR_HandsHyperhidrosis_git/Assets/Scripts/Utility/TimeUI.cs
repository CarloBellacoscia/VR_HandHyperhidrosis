using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TimeUI : MonoBehaviour
{
    public TextMeshProUGUI timeText;

    private void OnEnable()
    {
        TimeManager.OnSecondChanged += UpdateTime;
        TimeManager.OnMinuteChanged += UpdateTime;
    }

    private void OnDisable()
    {
        TimeManager.OnSecondChanged -= UpdateTime;
        TimeManager.OnMinuteChanged -= UpdateTime;
    }

    private void UpdateTime()
    {
        timeText.text = $"{TimeManager.Minute:00}:{TimeManager.Second:00}";
    }
}
