using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;

public class MenuScript : MonoBehaviour
{
    public GameObject menuPanel;
    public GameObject[] instruments;
    private bool isMenuVisible = false;
    private Dictionary<string, GameObject> instrumentDictionary;
    private GameObject CurrentInstrument;
    [SerializeField] private GameObject Scene;
    [SerializeField] private GameObject RightHand;
    [SerializeField] private GameObject ParentRightHand;

    void Start()
    {
        // Initially hide the menu and its instruments
        menuPanel.SetActive(false);
        // Create a dictionary to associate each instrument with its name
        instrumentDictionary = new Dictionary<string, GameObject>();

        foreach (GameObject instrument in instruments)
        {
            if (instrument.tag != "Hand")
            {
                instrument.SetActive(false);
                instrumentDictionary.Add(instrument.name, instrument);
            }
        }
    }

    void Update()
    {
        // Get the devices
        List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
        InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.Right, devices);

        Vector2 thumbstickValue = Vector2.zero;

        // Check each device
        foreach (var device in devices)
        {
            if (device.isValid)
            {
                // If the device has a thumbstick, get its value
                if (device.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primary2DAxis, out thumbstickValue))
                {
                    break;
                }
            }
        }

        // Determine the "pressure" based on the thumbstick's displacement
        float thumbstickPressure = thumbstickValue.magnitude;

        // Define a threshold for what you consider to be significant pressure
        float pressureThreshold = 0.1f;

        // Check if the "M" key or the thumbstick pressure exceeds the threshold
        if (Keyboard.current.mKey.wasPressedThisFrame || thumbstickPressure > pressureThreshold)
        {
            // Toggle the visibility of the menu
            isMenuVisible = !isMenuVisible;
            menuPanel.SetActive(isMenuVisible);
        }

    }


    // Function to get an instrument by name
    public GameObject GetInstrumentByName(string name)
    {
        if (instrumentDictionary.ContainsKey(name))
        {
            return instrumentDictionary[name];
        }
        else
        {
            Debug.LogError("Instrument not found: " + name);
            return null;
        }
    }
    public void ResetMesh()
    {
        if(CurrentInstrument != null)
        {
            CurrentInstrument.transform.SetParent(Scene.transform);

            if (CurrentInstrument.tag == "Instrument")
            {
                CurrentInstrument.gameObject.GetComponent<CapsuleCollider>().enabled = true;
            }

            CurrentInstrument.SetActive(false);
            CurrentInstrument = null;
        }

        RightHand.gameObject.SetActive(true);
    }

    public void ChangeMesh(string name)
    {
        RightHand.gameObject.SetActive(false);

        CurrentInstrument = GetInstrumentByName(name).gameObject;

        CurrentInstrument.SetActive(true);
        CurrentInstrument.transform.SetParent(ParentRightHand.transform);

        if (CurrentInstrument.tag == "Instrument")
        {
            CurrentInstrument.gameObject.GetComponent<CapsuleCollider>().enabled = false;
        }

        CurrentInstrument.transform.position = RightHand.transform.position;
        CurrentInstrument.transform.rotation = RightHand.transform.rotation;
        //CurrentInstrument.transform.rotation = Camera.main.transform.rotation;
    }
}
