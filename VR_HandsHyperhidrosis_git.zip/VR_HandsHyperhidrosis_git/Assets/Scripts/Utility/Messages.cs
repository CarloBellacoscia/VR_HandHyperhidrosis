using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Messages : MonoBehaviour
{
    public List<GameObject> messages = new List<GameObject>();
    [SerializeField] private Canvas canvas;
    [SerializeField] private GameObject panel;

    void Start()
    {
        // Ensure the canvas is set to world space
        if (canvas.renderMode != RenderMode.WorldSpace)
        {
            Debug.LogError("Canvas is not set to World Space.");
            return;
        }
    }

    public void DisplayMessage(int i)
    {
        panel.SetActive(true);
        //Debug.Log("messages: " + messages.Count + " and i: " + i + " so the message is: " + messages[i].ToString());
        //if(i < messages.Count)
        messages[i].SetActive(true);
    }

    public void CloseAll()
    {
        panel.SetActive(false);
        foreach (var item in messages)
            item.SetActive(false);
    }
}
