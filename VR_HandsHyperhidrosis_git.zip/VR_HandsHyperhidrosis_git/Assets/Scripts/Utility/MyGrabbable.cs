using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyGrabbable : MonoBehaviour
{
    private bool isInside = false;
    private bool manipulating = false;

    Transform oldParent;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        bool isRightHand;
        bool atLeastOnePress = HandleControllers.checkAtLeastOnePress(out isRightHand);
        Transform mainHandTransform = HandleControllers.getMainHandTransform(isRightHand);

        if (!manipulating)
        {
            if (isInside && atLeastOnePress)
            {
                oldParent = transform.parent;
                transform.SetParent(mainHandTransform);
                manipulating = true;
            }
        }
        else
        {
            if (atLeastOnePress)
            {

            }
            else
            {
                manipulating = false;
                transform.SetParent(oldParent);
            }
        }
    }
    public void HandHoverEnter()
    {
        isInside = true;
    }

    public void HandHoverExit()
    {
        isInside = false;
    }
}
