using UnityEngine;

public class TransformConstraints : MonoBehaviour
{
    [SerializeField] public Vector3 positionMinimum = new Vector3(-5f, 0f, -5f);
    [SerializeField] public Vector3 positionMaximum = new Vector3(5f, 10f, 5f);

    [SerializeField] public Vector3 rotationMinimum = new Vector3(-45f, -45f, -45f);
    [SerializeField] public Vector3 rotationMaximum = new Vector3(45f, 45f, 45f);

    private Quaternion initialRotation;
    private Vector3 initialPosition;
    private bool active = false;

    void Start()
    {
        //SetInitialPositionAndRotation();
    }

    void Update()
    {
        if (active)
        {
            ClampPositionAndRotation();
        }
    }

    void ClampPositionAndRotation()
    {
        // Calculate deltas
        Vector3 positionDelta = transform.position - initialPosition;
        Quaternion rotationDelta = Quaternion.Inverse(initialRotation) * transform.rotation;

        // Clamp position delta
        /*
        Vector3 clampedPositionDelta = new Vector3(
            Mathf.Clamp(positionDelta.x, positionMinimum.x, positionMaximum.x),
            Mathf.Clamp(positionDelta.y, positionMinimum.y, positionMaximum.y),
            Mathf.Clamp(positionDelta.z, positionMinimum.z, positionMaximum.z));
        

        Vector3 clampedPositionDelta = new Vector3(
            Mathf.Clamp(transform.position.x, positionMinimum.x, positionMaximum.x),
            Mathf.Clamp(transform.position.y, positionMinimum.y, positionMaximum.y),
            Mathf.Clamp(transform.position.z, positionMinimum.z, positionMaximum.z));

        // Apply clamped position
        transform.position = clampedPositionDelta;

        */

        Vector3 clampedPositionDelta = new Vector3(
            Mathf.Clamp(transform.position.x, transform.position.x, transform.position.x),
            Mathf.Clamp(transform.position.y, transform.position.y, transform.position.y),
            Mathf.Clamp(transform.position.z - 0.5f, transform.position.z, transform.position.z + 0.5f));

        // Apply clamped position
        transform.position = clampedPositionDelta;

        // Clamp rotation delta
        Vector3 deltaEuler = rotationDelta.eulerAngles;

        /*
        Vector3 clampedDeltaEuler = new Vector3(
            ClampAngle(deltaEuler.x, rotationMinimum.x, rotationMaximum.x),
            ClampAngle(deltaEuler.y, rotationMinimum.y, rotationMaximum.y),
            ClampAngle(deltaEuler.z, rotationMinimum.z, rotationMaximum.z));
        

        Vector3 clampedDeltaEuler = new Vector3(
            ClampAngle(transform.rotation.x, rotationMinimum.x, rotationMaximum.x),
            ClampAngle(transform.rotation.y, rotationMinimum.y, rotationMaximum.y),
            ClampAngle(transform.rotation.z, rotationMinimum.z, rotationMaximum.z));

        // Apply clamped rotation
        transform.rotation = Quaternion.Euler(clampedDeltaEuler);
        */
    }

    public void SetInitialPositionAndRotation()
    {
        initialPosition = transform.position;
        initialRotation = transform.rotation;

        active = true;
    }

    // Helper method to clamp angles between -180 and 180 degrees
    private float ClampAngle(float angle, float min, float max)
    {
        angle = NormalizeAngle(angle);
        min = NormalizeAngle(min);
        max = NormalizeAngle(max);
        return Mathf.Clamp(angle, min, max);
    }

    private float NormalizeAngle(float angle)
    {
        while (angle > 180f) angle -= 360f;
        while (angle < -180f) angle += 360f;
        return angle;
    }
}
