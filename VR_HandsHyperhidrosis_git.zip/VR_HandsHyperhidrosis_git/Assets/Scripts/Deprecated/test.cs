using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class test : MonoBehaviour
{
    [SerializeField] private GameObject RightHand;
    [SerializeField] private GameObject ParentRightHand;
    [SerializeField] private GameObject LeftHand;
    [SerializeField] private GameObject ParentLeftHand;

    private void OnTriggerEnter(Collider other)
    {
        if (other.name.Equals(RightHand.name) && RightHand.activeSelf == true)
        {
            RightHand.gameObject.SetActive(false);

            if (this.transform.parent.transform.parent.gameObject.name.Equals(ParentLeftHand.name))
            {
                LeftHand.gameObject.SetActive(true);
            }

            this.transform.parent.transform.SetParent(ParentRightHand.transform);
            //this.transform.parent.gameObject.GetComponent<CapsuleCollider>().enabled = false;

            this.transform.position = RightHand.transform.position;
            this.transform.rotation = RightHand.transform.rotation;

            /*
            if (this.GetComponent<PositionConstraints>() != null)
            {
                this.GetComponent<PositionConstraints>().disable();
                this.GetComponent<PositionConstraints>().resetPosition();
            }

            if (this.GetComponent<RotationConstraints>() != null)
            {
                this.GetComponent<RotationConstraints>().disable();
                this.GetComponent<RotationConstraints>().resetRotation();
            }
            */

        }
        else if (other.name.Equals(LeftHand.name) && LeftHand.activeSelf == true)
        {
            LeftHand.gameObject.SetActive(false);

            if (this.transform.parent.transform.parent.gameObject.name.Equals(ParentRightHand.name))
            {
                RightHand.gameObject.SetActive(true);

            }

            this.transform.parent.transform.SetParent(ParentLeftHand.transform);
            //this.transform.parent.gameObject.GetComponent<CapsuleCollider>().enabled = false;

            this.transform.parent.transform.position = LeftHand.transform.position;
            this.transform.parent.transform.rotation = LeftHand.transform.rotation;
            this.transform.parent.transform.Rotate(180, 0, 0);

            if (this.GetComponent<LookObject>() != null)
            {
                this.GetComponent<LookObject>().deactivate();
            }

            if (this.GetComponent<PositionConstraints>() != null)
            {
                this.GetComponent<PositionConstraints>().disable();
                this.GetComponent<PositionConstraints>().resetPosition();
            }

            if (this.GetComponent<RotationConstraints>() != null)
            {
                this.GetComponent<RotationConstraints>().disable();
                this.GetComponent<RotationConstraints>().resetRotation();
            }

        }
    }

}
