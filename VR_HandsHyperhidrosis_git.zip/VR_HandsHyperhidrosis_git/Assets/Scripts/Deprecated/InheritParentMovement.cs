using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InheritParentMovement : MonoBehaviour
{
    private Transform parentTransform;
    private bool active = false;

    void Start()
    {
        // Get the parent's Transform component
        parentTransform = transform.parent.GetComponent<Transform>();
    }

    void Update()
    {
        if (active)
        {
            if (parentTransform != null)
            {
                // Inherit the parent's position
                transform.position = parentTransform.position;

                // Inherit the parent's rotation
                transform.rotation = parentTransform.rotation;

                // Cancel out parent's movement along the Y-axis
                Vector3 parentVelocity = parentTransform.GetComponent<Rigidbody>().velocity;
                Vector3 childVelocity = GetComponent<Rigidbody>().velocity;
                childVelocity.y -= parentVelocity.y;
                GetComponent<Rigidbody>().velocity = childVelocity;
            }
        }
    }

    public void actvation()
    {
        active = true;
    }
}

