using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.InputSystem;

public class InstrumentChoice : MonoBehaviour
{
    public GameObject controller;
    public GameObject panelPrefab;
    public List<GameObject> gameObjectsList; // List of game objects to display

    private bool isPanelActive = false;
    private GameObject activePanel;

    void Update()
    {
        if (controller == null)
        {
            Debug.LogError("Controller not assigned!");
            return;
        }

        if ((controller.GetComponent<XRController>().inputDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool isButtonPressed) && isButtonPressed)
            || Keyboard.current.mKey.wasPressedThisFrame)
        {
            ToggleUI();
        }
    }

    void ToggleUI()
    {
        if (isPanelActive)
        {
            Destroy(activePanel);
            isPanelActive = false;
        }
        else
        {
            activePanel = Instantiate(panelPrefab, controller.transform.position + controller.transform.forward * 2f, controller.transform.rotation);
            isPanelActive = true;

            // Populate the list dynamically
            GameObject content = activePanel.GetComponentInChildren<ScrollRect>().content.gameObject;
            foreach (GameObject obj in gameObjectsList)
            {
                Instantiate(obj, content.transform);
            }
        }
    }
}
