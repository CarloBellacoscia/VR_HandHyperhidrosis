using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class TransferMovement : MonoBehaviour
{
    [SerializeField] private GameObject Object = null; // The Object that will be moved
    [SerializeField] private Vector3 shift = new Vector3(0f, 0f, 0f); // The shift of the object

    private Vector3 minPosition = new Vector3(); // The minimum possible position of the object
    private Vector3 maxPosition = new Vector3(); // The maximum possible position of the object
    private Vector3 offset = new Vector3(); // The offset between the object and the handle

    private bool active = false; // If the script is active
    private bool check = false; // bool to check if the object is in the right position

    // Start is called before the first frame update
    void Start()
    {
        if (Object == null)
        {
            Debug.LogError("Please assign the object to the script.");
        }
        else {             
            minPosition = Object.transform.position - shift;
            maxPosition = Object.transform.position + shift;

            offset = Object.transform.position - this.transform.position;
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        if (active)
        {
            if (Object != null && checkPosition())
            {
                // Inherit the handle's position
                Object.transform.position = this.transform.position + offset;

                // Inherit the handle's rotation
                Object.transform.rotation = this.transform.rotation;

            }
        }
    }

    public void activation()
    {
        offset = Object.transform.position - this.transform.position;

        active = true;
    }

    public void deactivation()
    {
        active = false;
    }

    public void resetPosition()
    {
        this.transform.position = Object.transform.position - offset;
    }

    private bool checkPosition()
    {
        if (this.transform.position.x + offset.x <= minPosition.x || this.transform.position.x + offset.x > maxPosition.x) 
        { 
            check = false;
            resetPosition();
        }
        else 
            check = true;

        if (this.transform.position.y + offset.y <= minPosition.y || this.transform.position.y + offset.y > maxPosition.y)
        {
            check = false;
            resetPosition();
        }
        else
            check = true;

        if (this.transform.position.z + offset.z <= minPosition.z || this.transform.position.z + offset.z > maxPosition.z)
        {
            check = false;
            resetPosition();
        }
        else
            check = true;

        return check;
    }   
}
