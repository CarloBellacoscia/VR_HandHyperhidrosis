using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProximityInteraction : MonoBehaviour
{
    public GameObject objectA = null; // The moving object, possibly a VR hand or controller
    public GameObject objectB = null; // The target object
    public float interactionDistance = 0.5f; // Distance within which an interaction occurs

    [SerializeField] private GameObject canvas;
    private bool activated = false;

    //bool activated = false;


    private void Start()
    {
        // Check if the objects are assigned
        if (objectA == null)
        {
            objectA = this.gameObject;
        }
    }
    // Update is called once per frame
    void Update()
    {
        if (objectA == null)
        {
            Debug.LogError("Please assign the objects to the ProximityInteraction script.");
        }else
        {
            CheckProximityAndInteract();
        }   
    }

    private void CheckProximityAndInteract()
    {
        //if (!activated)
        //{
        //activated = true;
        float distance = Vector3.Distance(objectA.transform.position, objectB.transform.position);

        if (distance <= interactionDistance)
        {
            // Trigger the interaction
            PerformInteraction();
            activated = true;
        }
        else
        {
            if (activated)
            {
                canvas.GetComponent<Messages>().CloseAll();
                activated = false;
            }   
        }
        //}
    }

    private void PerformInteraction()
    {
        canvas.GetComponent<Messages>().DisplayMessage(1);
    }
}
