using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;

public class InsertInstrument : MonoBehaviour
{
    private GameObject objectA = null; // The moving object, possibly a VR hand or controller
    private GameObject objectB = null; // The target object position

    [SerializeField] private bool Laparoscope;

    [SerializeField] private GameObject RightHandController;
    [SerializeField] private GameObject LeftHandController;

    [SerializeField] private GameObject GameController;

    private GameObject RightHand = null;
    private GameObject ParentRightHand = null;
    private GameObject LeftHand = null;
    private GameObject ParentLeftHand = null;

    bool leftPrimaryPress = false;
    bool leftSecondaryPress = false;
    bool rightPrimaryPress = false;
    bool rightSecondaryPress = false;

    [SerializeField] private Vector3 InstrumentPosition;
    [SerializeField] private Vector3 InstrumentRotation;
    [SerializeField] private Vector3 LaparoscopePosition;
    [SerializeField] private Vector3 LaparoscopeRotation;

    [SerializeField] private GameObject Scene;
    [SerializeField] private GameObject Trocar;
    private GameObject LaparoscopeHole;
    public GameObject messages;

    private GameObject Handle;

    //bool activated = true;

    private void Start()
    {
        objectA = this.gameObject;
        // Check if the objects are assigned
        if (objectA == null)
        {
            Debug.LogError("Please assign the objects to the ProximityInteraction script.");
        }
    }

    // Update is called once per frame
    void Update()
    {
        RightHand = RightHandController.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject;
        ParentRightHand = RightHandController.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.transform.GetChild(1).gameObject;
        LeftHand = LeftHandController.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject;
        ParentLeftHand = LeftHandController.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.transform.GetChild(1).gameObject;

        checkButton(out leftPrimaryPress, out leftSecondaryPress, out rightPrimaryPress, out rightSecondaryPress);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (ParentRightHand.transform.childCount > 0)
        {
            objectB = ParentRightHand.transform.GetChild(0).transform.GetChild(0).gameObject;
            Handle = ParentRightHand.transform.GetChild(0).transform.GetChild(1).gameObject;

            SetInitialTransform(other);
        }
        else if (ParentLeftHand.transform.childCount > 0)
        {
            objectB = ParentLeftHand.transform.GetChild(0).transform.GetChild(0).gameObject;
            Handle = ParentLeftHand.transform.GetChild(0).transform.GetChild(1).gameObject;

            SetInitialTransform(other);
        }
        else
        {
            objectB = null;
            //other.gameObject.GetComponent<HandInteraction>().laparoscopeTrigger();
        }

        // Ensure we only track the first object and ignore subsequent ones
        
    }

    private void OnTriggerStay(Collider other)
    {
        SetLookObj(other);
    }

    private void OnTriggerExit(Collider other)
    {
        DisableLookObj(other);
    }

    void SetInitialTransform(Collider other)
    {
        if (Laparoscope && other.gameObject.name.Equals("Laparoscope_Object"))
        {
            if (other.gameObject.transform.parent.transform.parent.gameObject.name.Equals(ParentLeftHand.name) && !(leftPrimaryPress || Keyboard.current.fKey.isPressed))
            {
                //LeftHand.gameObject.SetActive(true);
                LeftHandController.transform.GetChild(0).gameObject.GetComponent<BoxCollider>().enabled = true;
                other.gameObject.GetComponent<CapsuleCollider>().enabled = false;

                LaparoscopeHole = GameObject.Find("Scene/Laparoscope_hole");
                LaparoscopeHole.gameObject.GetComponent<CapsuleCollider>().enabled = true;

                other.gameObject.transform.parent.transform.SetParent(LaparoscopeHole.transform);
                other.gameObject.transform.parent.transform.position = LaparoscopePosition;
                other.gameObject.transform.parent.transform.eulerAngles = LaparoscopeRotation;
            }
            else if (other.gameObject.transform.parent.transform.parent.gameObject.name.Equals(ParentRightHand.name) && !(rightPrimaryPress || Keyboard.current.gKey.isPressed))
            {
                //RightHand.gameObject.SetActive(true);
                RightHandController.transform.GetChild(0).gameObject.GetComponent<BoxCollider>().enabled = true;
                other.gameObject.GetComponent<CapsuleCollider>().enabled = false;

                LaparoscopeHole = GameObject.Find("Scene/Laparoscope_hole");
                LaparoscopeHole.gameObject.GetComponent<CapsuleCollider>().enabled = true;

                other.gameObject.transform.parent.transform.SetParent(LaparoscopeHole.transform);
                other.gameObject.transform.parent.transform.position = LaparoscopePosition;
                other.gameObject.transform.parent.transform.eulerAngles = LaparoscopeRotation;
            }
            //Handle.GetComponent<CapsuleCollider>().enabled = true;

        }
        else if (!Laparoscope && !other.gameObject.name.Equals("Laparoscope_Object"))
        {
            //other.gameObject.transform.parent.transform.parent.transform.position = InstrumentPosition;
            //other.gameObject.transform.parent.transform.parent.transform.eulerAngles = InstrumentRotation;
            //other.gameObject.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionY;
            
            /*
            if (other.gameObject.transform.parent.transform.parent.gameObject.name.Equals(ParentLeftHand.name))
            {
                LeftHand.gameObject.SetActive(true);
            }
            else if (other.gameObject.transform.parent.transform.parent.gameObject.name.Equals(ParentRightHand.name))
            {
                RightHand.gameObject.SetActive(true);
            }
            */
            
            /*
            //other.gameObject.transform.parent.transform.SetParent(Trocar.transform);
            other.gameObject.transform.parent.transform.position = InstrumentPosition;
            other.gameObject.transform.parent.transform.eulerAngles = InstrumentRotation;
            //Handle.GetComponent<CapsuleCollider>().enabled = true;
            //other.gameObject.GetComponent<CapsuleCollider>().enabled = false;
            //other.gameObject.GetComponent<SphereCollider>().enabled = true;
            */

            /*
            if (activated)
            {
                activated = false;
                //objectB.GetComponent<PositionConstraints>().SetInitialPosition();
                other.transform.parent.gameObject.GetComponent<LookObject>().activate();
                //objectB.GetComponent<InheritParentMovement>().actvation();
                //Handle.GetComponent<TransferMovement>().activation();
            }
            */
            
        }
        else if (Laparoscope && !other.gameObject.name.Equals("Laparoscope"))
        {
            messages.GetComponent<Messages>().DisplayMessage(3);
            Debug.Log("You can only insert the laparoscope here");
        } else if (!Laparoscope && other.gameObject.name.Equals("Laparoscope"))
        {
            messages.GetComponent<Messages>().DisplayMessage(4);
            Debug.Log("You can only insert the instruments here");
        }

        
    }

    void SetLookObj(Collider other)
    {
        if (!Laparoscope && other.gameObject.name.Equals("ClipApplicator_Object"))
        {
            other.transform.parent.gameObject.GetComponent<LookObject>().activate();

        }else if (!Laparoscope && !other.gameObject.name.Equals("Laparoscope_Object") && !other.gameObject.name.Equals("ClipApplicator_Object"))
        {
            other.gameObject.GetComponent<LookObject>().activate();
        }
        else if (Laparoscope && other.gameObject.name.Equals("Laparoscope_Object"))
        {
            //other.gameObject.GetComponent<HandInteraction>().laparoscopeTrigger();
            //other.gameObject.GetComponent<LookObject>().activate();
        }
    }

    void DisableLookObj(Collider other)
    {
        if (!Laparoscope && other.gameObject.name.Equals("ClipApplicator_Object"))
        {
            //other.transform.parent.gameObject.GetComponent<LookObject>().deactivate();
            //GameController.GetComponent<MoveObjHands>().AlignInstruments();

            // /*
            if (other.gameObject.transform.parent.transform.parent.gameObject.name.Equals(ParentLeftHand.name))
            {
                other.transform.parent.transform.rotation = Quaternion.Euler(LeftHand.transform.rotation.eulerAngles);
                other.transform.parent.transform.Rotate(150, 0, 180);
            }
            else if (other.gameObject.transform.parent.transform.parent.gameObject.name.Equals(ParentRightHand.name))
            {
                other.transform.parent.transform.rotation = Quaternion.Euler(RightHand.transform.rotation.eulerAngles);
                other.transform.parent.transform.Rotate(-30, 0, 180);
            }
            // */
        }
        else if (!Laparoscope && !other.gameObject.name.Equals("Laparoscope_Object") && !other.gameObject.name.Equals("ClipApplicator_Object"))
        {
            //other.gameObject.GetComponent<LookObject>().deactivate();
            //GameController.GetComponent<MoveObjHands>().AlignInstruments();

            // /*
            if (other.gameObject.transform.parent.transform.parent.gameObject.name.Equals(ParentLeftHand.name))
            {
                other.transform.rotation = Quaternion.Euler(LeftHand.transform.rotation.eulerAngles);
                other.transform.Rotate(150, 0, 0);
            }
            else if (other.gameObject.transform.parent.transform.parent.gameObject.name.Equals(ParentRightHand.name))
            {
                other.transform.rotation = Quaternion.Euler(RightHand.transform.rotation.eulerAngles);
                other.transform.Rotate(-30, 0, 0);
            }
            // */
        }
    }

    private void checkButton(out bool leftPrimaryPress, out bool leftSecondaryPress, out bool rightPrimaryPress, out bool rightSecondaryPress)
    {
        UnityEngine.XR.InputDevice leftDevice;
        UnityEngine.XR.InputDevice rightDevice;

        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                leftPrimaryPress = primaryButtonValue;
                leftSecondaryPress = secondaryButtonValue;
            }
            else
            {
                leftPrimaryPress = false;
                leftSecondaryPress = false;
            }
        }
        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                rightPrimaryPress = primaryButtonValue;
                rightSecondaryPress = secondaryButtonValue;
            }
            else
            {
                rightPrimaryPress = false;
                rightSecondaryPress = false;
            }

        }
    }
}
