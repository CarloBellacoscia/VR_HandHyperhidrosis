using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchColliders : MonoBehaviour
{
    private GameObject instrument = null; // The instrument game object
    private GameObject instrument_object = null; // The instrument object with multiple colliders
    private GameObject instrument_handle = null; // The instrument handle object

    ///*
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        /*
        if (this.transform.childCount > 1)
        {
            // Get the instrument game object
            instrument = this.transform.GetChild(1).gameObject;
            Debug.Log("childs: " + instrument.transform.childCount + ", " + instrument.transform.GetChild(0).name + ", " + instrument.transform.GetChild(1).name);
            instrument_object = instrument.transform.GetChild(0).gameObject;
            instrument_handle = instrument.transform.GetChild(1).gameObject;
        }
        */
    }

    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("Collision detected");

        if (this.transform.childCount > 1)
        {
            // Get the instrument game object
            instrument = this.transform.GetChild(1).gameObject;
            Debug.Log("childs: " + instrument.transform.childCount + ", " + instrument.transform.GetChild(0).name + ", " + instrument.transform.GetChild(1).name);

            instrument_object = instrument.transform.GetChild(0).gameObject;
            instrument_handle = instrument.transform.GetChild(1).gameObject;

            if (instrument_handle.GetComponent<CapsuleCollider>().enabled == true)
            {
                Debug.Log("Switching colliders");
                // Enable the capsule collider and disable the sphere collider of the object component
                instrument_object.GetComponent<CapsuleCollider>().enabled = true;
                instrument_object.GetComponent<SphereCollider>().enabled = false;

                // Disable the capsule collider of the handle component
                instrument_handle.GetComponent<CapsuleCollider>().enabled = false;
            }
            else
            {
                // Disable the capsule collider and enable the sphere collider of the object component
                instrument_object.GetComponent<CapsuleCollider>().enabled = false;
                instrument_object.GetComponent<SphereCollider>().enabled = true;

                // Enable the capsule collider of the handle component
                instrument_handle.GetComponent<CapsuleCollider>().enabled = true;
            }
        }
    }
    //*/

    /*
    private GameObject objectA = null; // The moving object, possibly a VR hand or controller
    public GameObject objectB = null; // The target object
    public float interactionDistance = 0.1f; // Distance within which an interaction occurs


    private void Start()
    {
        // Check if the objects are assigned
        if (objectA == null)
        {
            objectA = this.gameObject;
        }
    }
    // Update is called once per frame
    void Update()
    {
        if (objectA == null)
        {
            Debug.LogError("Please assign the objects to the ProximityInteraction script.");
        }
        else if (objectA.transform.childCount > 1)
        {
            // Get the instrument game object
            instrument = this.transform.GetChild(1).gameObject;
            instrument_object = instrument.transform.GetChild(0).gameObject;
            instrument_handle = instrument.transform.GetChild(1).gameObject;

            CheckProximityAndInteract();
        }
    }

    private void CheckProximityAndInteract()
    {
        float distance = Vector3.Distance(objectA.transform.position, objectB.transform.position);

        if (distance <= interactionDistance)
        {
            // Trigger the interaction
            PerformInteraction();
        }
    }

    private void PerformInteraction()
    {
        if (instrument_handle.GetComponent<CapsuleCollider>().enabled)
        {
            // Disable the capsule collider and enable the sphere collider of the object component
            instrument_object.GetComponent<CapsuleCollider>().enabled = false;
            instrument_object.GetComponent<SphereCollider>().enabled = true;

            // Enable the capsule collider of the handle component
            instrument_handle.GetComponent<CapsuleCollider>().enabled = true;
        }
        else
        {
            // Enable the capsule collider and disable the sphere collider of the object component
            instrument_object.GetComponent<CapsuleCollider>().enabled = true;
            instrument_object.GetComponent<SphereCollider>().enabled = false;

            // Disable the capsule collider of the handle component
            instrument_handle.GetComponent<CapsuleCollider>().enabled = false;
        }
    }
    */
}
