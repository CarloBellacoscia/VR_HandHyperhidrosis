using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class ReleaseObject : MonoBehaviour
{
    public GameObject[] instruments;
    private List<Vector3> initialPositions = new List<Vector3>();
    private List<Vector3> initialRotations = new List<Vector3>();

    [SerializeField] private GameObject RightHand;
    [SerializeField] private GameObject LeftHand;
    [SerializeField] private GameObject GameController;

    bool leftPrimaryPress = false;
    bool leftSecondaryPress = false;
    bool rightPrimaryPress = false;
    bool rightSecondaryPress = false;

    private bool release = false;
    private GameObject r_obj = null;
    private GameObject l_obj = null;

    // Start is called before the first frame update
    void Start()
    {
        foreach (GameObject instrument in instruments)
        {
            //initialPositions.Add(instrument.transform.parent.transform.position);
            //Debug.Log(instrument.transform.position);
            //initialRotations.Add(instrument.transform.parent.transform.eulerAngles);

            initialPositions.Add(instrument.transform.parent.transform.position);
            initialRotations.Add(instrument.transform.parent.transform.eulerAngles);
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        checkButton(out leftPrimaryPress, out leftSecondaryPress, out rightPrimaryPress, out rightSecondaryPress);

        if (release)
        {
            if (r_obj != null && !(rightPrimaryPress || Keyboard.current.gKey.isPressed))
            {
                RightHand.transform.parent.transform.parent.gameObject.GetComponent<BoxCollider>().enabled = true;

                r_obj.transform.parent.transform.SetParent(this.transform);

                r_obj.transform.parent.transform.position = GetPosition(r_obj.name);
                r_obj.transform.parent.transform.eulerAngles = GetRotation(r_obj.name);
                release = false;
            }
            else if (l_obj != null && !(leftPrimaryPress || Keyboard.current.fKey.isPressed))
            {
                LeftHand.transform.parent.transform.parent.gameObject.GetComponent<BoxCollider>().enabled = true;

                l_obj.transform.parent.transform.SetParent(this.transform);

                l_obj.transform.parent.transform.position = GetPosition(l_obj.name);
                l_obj.transform.parent.transform.eulerAngles = GetRotation(l_obj.name);
                release = false;
            }

        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.parent.transform.parent.name.Equals("RightInstrument"))
        {
            release = true;
            r_obj = other.gameObject;
        } 
        else if (other.transform.parent.transform.parent.name.Equals("LeftInstrument"))
        {
            release = true;
            l_obj = other.gameObject;
        }

         /*
        if (other.transform.parent.transform.parent.name.Equals("RightInstrument") &&  !(rightPrimaryPress || Keyboard.current.gKey.isPressed))
        {
            other.gameObject.GetComponent<HandInteraction>().onTable();

            //RightHand.gameObject.SetActive(true);
            RightHand.transform.parent.transform.parent.gameObject.GetComponent<BoxCollider>().enabled = true;

            other.gameObject.transform.parent.transform.SetParent(this.transform);
            //other.gameObject.transform.parent.transform.position = GetPosition(other.name);
            //other.gameObject.transform.parent.transform.eulerAngles = GetRotation(other.name);

            other.gameObject.transform.parent.transform.position = GetPosition(other.name);
            other.gameObject.transform.parent.transform.eulerAngles = GetRotation(other.name);

            GameController.GetComponent<MoveObjHands>().AlignInstruments();
        }
        else if (other.transform.parent.transform.parent.name.Equals("LeftInstrument") && !(leftPrimaryPress || Keyboard.current.fKey.isPressed))
        {
            other.gameObject.GetComponent<HandInteraction>().onTable();

            //LeftHand.gameObject.SetActive(true);
            LeftHand.transform.parent.transform.parent.gameObject.GetComponent<BoxCollider>().enabled = true;

            other.gameObject.transform.parent.transform.SetParent(this.transform);
            //other.gameObject.transform.parent.transform.position = GetPosition(other.name);
            //other.gameObject.transform.parent.transform.eulerAngles = GetRotation(other.name);

            other.gameObject.transform.parent.transform.position = GetPosition(other.name);
            other.gameObject.transform.parent.transform.eulerAngles = GetRotation(other.name);

            GameController.GetComponent<MoveObjHands>().AlignInstruments();
        }
        // */
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.transform.parent.transform.parent.name.Equals("RightInstrument"))
        {
            release = true;
            r_obj = other.gameObject;
        }
        else if (other.transform.parent.transform.parent.name.Equals("LeftInstrument"))
        {
            release = true;
            l_obj = other.gameObject;
        }

         /*
        if (other.transform.parent.transform.parent.name.Equals("RightInstrument") && !(rightPrimaryPress || Keyboard.current.gKey.isPressed))
        {
            Debug.Log("release");

            other.gameObject.GetComponent<HandInteraction>().onTable();

            //RightHand.gameObject.SetActive(true);
            RightHand.transform.parent.transform.parent.gameObject.GetComponent<BoxCollider>().enabled = true;

            other.gameObject.transform.parent.transform.SetParent(this.transform);
            //other.gameObject.transform.parent.transform.position = GetPosition(other.name);
            //other.gameObject.transform.parent.transform.eulerAngles = GetRotation(other.name);

            other.gameObject.transform.parent.transform.position = GetPosition(other.name);
            other.gameObject.transform.parent.transform.eulerAngles = GetRotation(other.name);

            GameController.GetComponent<MoveObjHands>().AlignInstruments();
        }
        else if (other.transform.parent.transform.parent.name.Equals("LeftInstrument") && !(leftPrimaryPress || Keyboard.current.fKey.isPressed))
        {
            other.gameObject.GetComponent<HandInteraction>().onTable();

            //LeftHand.gameObject.SetActive(true);
            LeftHand.transform.parent.transform.parent.gameObject.GetComponent<BoxCollider>().enabled = true;

            other.gameObject.transform.parent.transform.SetParent(this.transform);
            //other.gameObject.transform.parent.transform.position = GetPosition(other.name);
            //other.gameObject.transform.parent.transform.eulerAngles = GetRotation(other.name);

            other.gameObject.transform.parent.transform.position = GetPosition(other.name);
            other.gameObject.transform.parent.transform.eulerAngles = GetRotation(other.name);

            GameController.GetComponent<MoveObjHands>().AlignInstruments();
        }
        // */
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.transform.parent.transform.parent.name.Equals("RightInstrument"))
        {
            release = false;
            r_obj = null;
        }
        else if (other.transform.parent.transform.parent.name.Equals("LeftInstrument"))
        {
            release = false;
            l_obj = null;
        }
    }

    private void checkButton(out bool leftPrimaryPress, out bool leftSecondaryPress, out bool rightPrimaryPress, out bool rightSecondaryPress)
    {
        UnityEngine.XR.InputDevice leftDevice;
        UnityEngine.XR.InputDevice rightDevice;

        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                leftPrimaryPress = primaryButtonValue;
                leftSecondaryPress = secondaryButtonValue;
            }
            else
            {
                leftPrimaryPress = false;
                leftSecondaryPress = false;
            }
        }
        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                rightPrimaryPress = primaryButtonValue;
                rightSecondaryPress = secondaryButtonValue;
            }
            else
            {
                rightPrimaryPress = false;
                rightSecondaryPress = false;
            }

        }
    }

    public Vector3 GetPosition(string instrumentName)
    {
        for (int i = 0; i < instruments.Length; i++)
        {
            if (instruments[i].name.Equals(instrumentName))
            {
                return initialPositions[i];
            }
        }
        return Vector3.zero;
    }

    public Vector3 GetRotation(string instrumentName)
    {
        for (int i = 0; i < instruments.Length; i++)
        {
            if (instruments[i].name.Equals(instrumentName))
            {
                return initialRotations[i];
            }
        }
        return Vector3.zero;
    }
}
