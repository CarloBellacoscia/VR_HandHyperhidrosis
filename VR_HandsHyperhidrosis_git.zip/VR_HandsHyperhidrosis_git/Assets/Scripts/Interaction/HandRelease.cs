using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;

public class HandRelease : MonoBehaviour
{
    [SerializeField] private GameObject RightHand;
    [SerializeField] private GameObject LeftHand;

    [SerializeField] private GameObject Scene;
    //[SerializeField] private GameObject Handle;
    private bool active = true;
    private bool rho = false;
    private bool lho = false;

    private bool laparoscope = false;

    bool leftPrimaryPress = false;
    bool leftSecondaryPress = false;
    bool rightPrimaryPress = false;
    bool rightSecondaryPress = false;

    public void Update()
    {
        checkButton(out leftPrimaryPress, out leftSecondaryPress, out rightPrimaryPress, out rightSecondaryPress);

        if (rho && !(rightPrimaryPress || Keyboard.current.gKey.isPressed))
        {
            this.transform.parent.transform.SetParent(Scene.transform);
            rho = false;
            RightHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = true;
        }
        else if (lho && !(leftPrimaryPress || Keyboard.current.fKey.isPressed))
        {
            this.transform.parent.transform.SetParent(Scene.transform);
            lho = false;
            LeftHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = true;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.name.Equals(RightHand.name) && RightHand.activeSelf == true && (rightPrimaryPress || Keyboard.current.gKey.isPressed))
        {
            rho = true;
        }
        else if (other.name.Equals(LeftHand.name) && LeftHand.activeSelf == true && (leftPrimaryPress || Keyboard.current.fKey.isPressed))
        {
            lho = true;
        }
    }

    private void checkButton(out bool leftPrimaryPress, out bool leftSecondaryPress, out bool rightPrimaryPress, out bool rightSecondaryPress)
    {
        UnityEngine.XR.InputDevice leftDevice;
        UnityEngine.XR.InputDevice rightDevice;

        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                leftPrimaryPress = primaryButtonValue;
                leftSecondaryPress = secondaryButtonValue;
            }
            else
            {
                leftPrimaryPress = false;
                leftSecondaryPress = false;
            }
        }
        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                rightPrimaryPress = primaryButtonValue;
                rightSecondaryPress = secondaryButtonValue;
            }
            else
            {
                rightPrimaryPress = false;
                rightSecondaryPress = false;
            }

        }
    }
}
