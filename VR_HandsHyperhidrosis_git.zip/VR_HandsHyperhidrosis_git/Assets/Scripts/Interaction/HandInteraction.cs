using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class HandInteraction : MonoBehaviour
{
    [SerializeField] private GameObject RightHand;
    [SerializeField] private GameObject ParentRightHand;
    [SerializeField] private GameObject LeftHand;
    [SerializeField] private GameObject ParentLeftHand;

    [SerializeField] private GameObject Scene;
    //[SerializeField] private GameObject Handle;

    [SerializeField] private GameObject TimeManager;

    private GameObject LaparoscopeHole;

    private bool active = true;

    //private bool table = true;

    private bool rho = false;
    private bool lho = false;

    //private bool laparoscope = false;

    bool leftPrimaryPress = false;
    bool leftSecondaryPress = false;
    bool rightPrimaryPress = false;
    bool rightSecondaryPress = false;

    public void Update()
    {
        checkButton(out leftPrimaryPress, out leftSecondaryPress, out rightPrimaryPress, out rightSecondaryPress);

        if (!this.name.Equals("Laparoscope_Object"))
        {
            if (rho && !(rightPrimaryPress || Keyboard.current.gKey.isPressed))
            {
                this.transform.parent.transform.SetParent(Scene.transform);
                rho = false;
                RightHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = true;
            }
            else if (lho && !(leftPrimaryPress || Keyboard.current.fKey.isPressed))
            {
                this.transform.parent.transform.SetParent(Scene.transform);
                lho = false;
                LeftHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = true;
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.name.Equals(RightHand.name) && RightHand.activeSelf == true && (rightPrimaryPress || Keyboard.current.gKey.isPressed))
        {
            if (active)
            {
                TimeManager.GetComponent<TimeManager>().StartTimer();
                active = false;
            }

            // /*
            //RightHand.gameObject.SetActive(false);
            RightHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = false;

            if (this.transform.parent.transform.parent.gameObject.name.Equals(ParentLeftHand.name))
            {
                //LeftHand.gameObject.SetActive(true);
                //LeftHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = false;

            }
            // */

            this.transform.parent.transform.SetParent(ParentRightHand.transform);
            this.transform.parent.transform.position = other.transform.position;
            this.transform.parent.transform.rotation = other.transform.rotation;
            
            if(this.name.Equals("ClipApplicator_Object"))
            {
                this.transform.parent.transform.Rotate(-30, 0, 180);
            }
            else
            {
                this.transform.parent.transform.Rotate(-30, 0, 0);
            }

            rho = true;

            /*
            if (this.GetComponent<LookObject>() != null)
            {
                this.GetComponent<LookObject>().deactivate();
            }

            if (this.GetComponent<PositionConstraints>() != null)
            {
                this.GetComponent<PositionConstraints>().disable();
                this.GetComponent<PositionConstraints>().resetPosition();
            }

            if (this.GetComponent<RotationConstraints>() != null)
            {
                this.GetComponent<RotationConstraints>().disable();
                this.GetComponent<RotationConstraints>().resetRotation();
            }
            */

        }
        else if (other.name.Equals(LeftHand.name) && LeftHand.activeSelf == true && (leftPrimaryPress || Keyboard.current.fKey.isPressed))
        {
            if (active)
            {
                TimeManager.GetComponent<TimeManager>().StartTimer();
                active = false;
            }

            // /*
            //LeftHand.gameObject.SetActive(false);
            LeftHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = false;

            if (this.transform.parent.transform.parent.gameObject.name.Equals(ParentRightHand.name))
            {
                //RightHand.gameObject.SetActive(true);
                //RightHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = false;
            }
            // */

            this.transform.parent.transform.SetParent(ParentLeftHand.transform);
            this.transform.parent.transform.position = other.transform.position;
            this.transform.parent.transform.rotation = other.transform.rotation;

            if (this.name.Equals("ClipApplicator_Object"))
            {
                this.transform.parent.transform.Rotate(-30, 0, 0);
            }
            else
            {
                this.transform.parent.transform.Rotate(-30, 0, 0);
            }

            lho = true;

            /*
            if (this.GetComponent<LookObject>() != null)
            {
                this.GetComponent<LookObject>().deactivate();
            }
            
            if (this.GetComponent<PositionConstraints>() != null)
            {
                this.GetComponent<PositionConstraints>().disable();
                this.GetComponent<PositionConstraints>().resetPosition();
            }

            if (this.GetComponent<RotationConstraints>() != null)
            {
                this.GetComponent<RotationConstraints>().disable();
                this.GetComponent<RotationConstraints>().resetRotation();
            }
            */

        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.name.Equals(RightHand.name) && RightHand.activeSelf == true && (rightPrimaryPress || Keyboard.current.gKey.isPressed))
        {
            if (active)
            {
                TimeManager.GetComponent<TimeManager>().StartTimer();
                active = false;
            }

            RightHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = false;

            if (this.transform.parent.transform.parent.gameObject.name.Equals(ParentLeftHand.name))
            {
                //LeftHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = false;
            }

            this.transform.parent.transform.SetParent(ParentRightHand.transform);
            this.transform.parent.transform.position = other.transform.position;
            this.transform.parent.transform.rotation = other.transform.rotation;

            if (this.name.Equals("ClipApplicator_Object"))
            {
                this.transform.parent.transform.Rotate(-30, 0, 180);
            }
            else
            {
                this.transform.parent.transform.Rotate(-30, 0, 0);
            }

            rho = true;
        }
        else if (other.name.Equals(LeftHand.name) && LeftHand.activeSelf == true && (leftPrimaryPress || Keyboard.current.fKey.isPressed))
        {
            if (active)
            {
                TimeManager.GetComponent<TimeManager>().StartTimer();
                active = false;
            }

            LeftHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = false;

            if (this.transform.parent.transform.parent.gameObject.name.Equals(ParentRightHand.name))
            {
                //RightHand.transform.parent.transform.parent.gameObject.gameObject.GetComponent<BoxCollider>().enabled = false;
            }

            this.transform.parent.transform.SetParent(ParentLeftHand.transform);
            this.transform.parent.transform.position = other.transform.position;
            this.transform.parent.transform.rotation = other.transform.rotation;

            if (this.name.Equals("ClipApplicator_Object"))
            {
                this.transform.parent.transform.Rotate(-30, 0, 0);
            }
            else
            {
                this.transform.parent.transform.Rotate(-30, 0, 0);
            }

            lho = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
         /*
        if (laparoscope && other.gameObject.name.Equals("Laparoscope_Object"))
        {
            LaparoscopeHole = GameObject.Find("Scene/Laparoscope_hole");
            other.gameObject.transform.parent.transform.SetParent(LaparoscopeHole.transform);
        }
        // */
    }

    private void checkButton(out bool leftPrimaryPress, out bool leftSecondaryPress, out bool rightPrimaryPress, out bool rightSecondaryPress)
    {
        UnityEngine.XR.InputDevice leftDevice;
        UnityEngine.XR.InputDevice rightDevice;

        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                leftPrimaryPress = primaryButtonValue;
                leftSecondaryPress = secondaryButtonValue;
            }
            else
            {
                leftPrimaryPress = false;
                leftSecondaryPress = false;
            }
        }
        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                rightPrimaryPress = primaryButtonValue;
                rightSecondaryPress = secondaryButtonValue;
            }
            else
            {
                rightPrimaryPress = false;
                rightSecondaryPress = false;
            }

        }
    }
     /*
    public void laparoscopeTrigger()
    {
        if (!laparoscope)
        {
            laparoscope = true;
        }
        else
        {
            laparoscope = false;
        }
    }
    // */

     /*
    public void onTable()
    {
        table = true;
    }

    public void offTable()
    {
        table = false;
    }
    // */
}
