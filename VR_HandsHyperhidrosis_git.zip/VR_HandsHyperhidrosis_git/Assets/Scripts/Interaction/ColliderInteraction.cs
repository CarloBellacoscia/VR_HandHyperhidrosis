using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class ColliderInteraction : MonoBehaviour
{
    [SerializeField] private GameObject obj1;
    [SerializeField] private GameObject obj2;
    [SerializeField] private GameObject obj3;
    [SerializeField] private GameObject canvas;

    [SerializeField] private GameObject TimeManager;
    [SerializeField] private GameObject ErrorManager;

    private bool key1 = false;
    private bool key2 = false;
    private bool step1 = false;
    private bool step2 = false;
    private bool stop = true;

    bool leftPrimaryPress = false;
    bool leftSecondaryPress = false;
    bool rightPrimaryPress = false;
    bool rightSecondaryPress = false;

    private void Start()
    {
        obj1.GetComponent<ManageAnimation>().Start();
        obj2.GetComponent<ManageAnimation>().Start();
        obj3.GetComponent<ManageAnimation>().Start();
    }
    private void Update()
    {
        checkButton(out leftPrimaryPress, out leftSecondaryPress, out rightPrimaryPress, out rightSecondaryPress);

        if (obj3.GetComponent<ManageAnimation>().IsFinished())
        {
            TimeManager.GetComponent<TimeManager>().StopTimer();
        }
        else if (obj2.GetComponent<ManageAnimation>().IsFinished())
        {
            obj2.GetComponent<ManageAnimation>().StopAnimation();
            key2 = true;
            CheckTime(obj3);
        }
        else if (obj1.GetComponent<ManageAnimation>().IsFinished())
        {
            obj1.GetComponent<ManageAnimation>().StopAnimation();
            key1 = true;
            CheckTime(obj2);
            if (!step1 && stop)
            {
                obj2.GetComponent<ManageAnimation>().StopAnimation();
                stop = false;
            }
        }
        else
        {
            CheckTime(obj1);
        }
    }


    private void OnTriggerEnter(Collider other)
    {
        canvas.GetComponent<Messages>().CloseAll();

        // Start the animation when the collider enters
        if (key2)
        {
            EnableMesh(obj3);
            if (obj3.GetComponent<ManageAnimation>().time != 0)
            {
                if (step1 && other.tag == obj3.GetComponent<ManageAnimation>().instrument1) 
                { 
                    obj3.GetComponent<ManageAnimation>().ResumeAnimation(); 
                }else if (step2 && other.tag == obj3.GetComponent<ManageAnimation>().instrument2)
                {
                    obj3.GetComponent<ManageAnimation>().ResumeAnimation();
                }else
                {
                    canvas.GetComponent<Messages>().DisplayMessage(2);
                    ErrorManager.GetComponent<ErrorManager>().AddWarning();
                    Debug.Log("Wrong instrument");
                }
            }
            else if (string.Equals(other.tag, obj3.GetComponent<ManageAnimation>().instrument1))
            {
                obj3.GetComponent<ManageAnimation>().ResumeAnimation();
            } else
            {
                canvas.GetComponent<Messages>().DisplayMessage(2);
                ErrorManager.GetComponent<ErrorManager>().AddWarning();
                Debug.Log("Wrong instrument");
            }
        } else if (key1)
        {
            EnableMesh(obj2);
            if (obj2.GetComponent<ManageAnimation>().time != 0)
            {
                if (step1 && string.Equals(other.tag, obj2.GetComponent<ManageAnimation>().instrument1))
                {
                    obj2.GetComponent<ManageAnimation>().ResumeAnimation();
                    
                }
                else if (step2 && string.Equals(other.tag, obj2.GetComponent<ManageAnimation>().instrument2))
                {
                    obj2.GetComponent<ManageAnimation>().ResumeAnimation();
                }else
                {
                    canvas.GetComponent<Messages>().DisplayMessage(2);
                    ErrorManager.GetComponent<ErrorManager>().AddWarning();
                    Debug.Log("Wrong instrument");
                }
            }
            else if (string.Equals(other.tag, obj2.GetComponent<ManageAnimation>().instrument1))
            {
                obj2.GetComponent<ManageAnimation>().ResumeAnimation();
            }else
            {
                canvas.GetComponent<Messages>().DisplayMessage(2);
                ErrorManager.GetComponent<ErrorManager>().AddWarning();
                Debug.Log("Wrong instrument");
            }
        } else
        {
            EnableMesh(obj1);
            if (obj1.GetComponent<ManageAnimation>().time != 0)
            {
                if (step1 && string.Equals(other.tag, obj1.GetComponent<ManageAnimation>().instrument1))
                {
                    obj1.GetComponent<ManageAnimation>().ResumeAnimation();
                }
                else if (step2 && string.Equals(other.tag, obj1.GetComponent<ManageAnimation>().instrument2))
                {
                    obj1.GetComponent<ManageAnimation>().ResumeAnimation();
                }else
                {
                    canvas.GetComponent<Messages>().DisplayMessage(2);
                    ErrorManager.GetComponent<ErrorManager>().AddWarning();
                    Debug.Log("Wrong instrument");
                }
            }
            else if (string.Equals(other.tag, obj1.GetComponent<ManageAnimation>().instrument1))
            {
                obj1.GetComponent<ManageAnimation>().ResumeAnimation();
            }else
            {
                canvas.GetComponent<Messages>().DisplayMessage(2);
                ErrorManager.GetComponent<ErrorManager>().AddWarning();
                Debug.Log("Wrong instrument");
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        canvas.GetComponent<Messages>().CloseAll();
        // Stop the animation when the collider exits
        if (key2)
        {
            obj3.GetComponent<ManageAnimation>().StopAnimation();
        }
        else if (key1)
        {
            obj2.GetComponent<ManageAnimation>().StopAnimation();
        }
        else
        {
            obj1.GetComponent<ManageAnimation>().StopAnimation();
        }
    }

    private void CheckTime(GameObject obj)
    {
        if (obj.GetComponent<ManageAnimation>().time != 0)
        {
            if (obj.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).normalizedTime < obj.GetComponent<ManageAnimation>().time)
            {
                step1 = true;
                step2 = false;
            }
            else if (obj.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).normalizedTime > obj.GetComponent<ManageAnimation>().time)
            {
                step1 = false;
                step2 = true;
            }
        }
        else 
        { 
            step1 = true;
        }

    }

    private void EnableMesh(GameObject obj)
    {
        if (!string.Equals(tag, "MainCamera"))
        {
            if (!obj.GetComponent<ManageAnimation>().SkinnedMesh)
            {
                if (!obj.GetComponent<MeshRenderer>().enabled)
                {
                    obj.GetComponent<MeshRenderer>().enabled = true;
                }
            }
            else
            {
                if (!obj.GetComponent<SkinnedMeshRenderer>().enabled)
                {
                    obj.GetComponent<SkinnedMeshRenderer>().enabled = true;
                }
            }
        }
    }

    private void checkButton(out bool leftPrimaryPress, out bool leftSecondaryPress, out bool rightPrimaryPress, out bool rightSecondaryPress)
    {
        UnityEngine.XR.InputDevice leftDevice;
        UnityEngine.XR.InputDevice rightDevice;

        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                leftPrimaryPress = primaryButtonValue;
                leftSecondaryPress = secondaryButtonValue;
            }
            else
            {
                leftPrimaryPress = false;
                leftSecondaryPress = false;
            }
        }
        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                rightPrimaryPress = primaryButtonValue;
                rightSecondaryPress = secondaryButtonValue;
            }
            else
            {
                rightPrimaryPress = false;
                rightSecondaryPress = false;
            }

        }
    }
}
