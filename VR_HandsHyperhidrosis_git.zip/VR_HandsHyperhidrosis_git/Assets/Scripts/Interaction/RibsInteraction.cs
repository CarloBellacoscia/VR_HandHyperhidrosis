using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class RibsInteraction : MonoBehaviour
{
    [SerializeField] private GameObject obj;
    [SerializeField] private GameObject canvas;

    [SerializeField] private GameObject ErrorManager;

    private bool stop = true;
    private bool step1 = true;
    private bool step2 = false;

    private void Start()
    {
        obj.GetComponent<ManageAnimation>().Start();
        obj.GetComponent<ManageAnimation>().ResumeAnimation();
    }
    private void Update()
    {
        CheckTime(obj);
        if (!step1 && stop)
        {
            obj.GetComponent<ManageAnimation>().StopAnimation();
            stop = false;
            canvas.GetComponent<Messages>().DisplayMessage(0);
            Debug.Log("Indicate the ribs with an instrument");
        }
        
    }


    public void OnTriggerEnter(Collider other)
    {
        // Start the animation when the collider enters
        if (step1)
        {
            obj.GetComponent<ManageAnimation>().ResumeAnimation();
        }
        else if (step2)
        {
            obj.GetComponent<ManageAnimation>().ResumeAnimation();
        }else
        {
            canvas.GetComponent<Messages>().DisplayMessage(2);
            ErrorManager.GetComponent<ErrorManager>().AddWarning();
            Debug.Log("Wrong instrument");
        }
    }

    private void OnTriggerExit(Collider other)
    {

        // Stop the animation when the collider exits
        if (obj.GetComponent<Animator>() != null)
        {
            //obj.GetComponent<ManageAnimation>().StopAnimation();
            canvas.GetComponent<Messages>().CloseAll();
            canvas.GetComponent<Messages>().DisplayMessage(2);
        }
    }

    private void CheckTime(GameObject obj)
    {
        if (obj.GetComponent<ManageAnimation>().time != 0)
        {
            if (obj.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).normalizedTime < obj.GetComponent<ManageAnimation>().time)
            {
                step1 = true;
                step2 = false;
            }
            else if (obj.GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).normalizedTime > obj.GetComponent<ManageAnimation>().time)
            {
                step1 = false;
                step2 = true;
            }
        }
        else
        {
            step1 = true;
        }

    }
}

