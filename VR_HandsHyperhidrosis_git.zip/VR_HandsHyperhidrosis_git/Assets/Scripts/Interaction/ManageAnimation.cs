using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;

public class ManageAnimation : MonoBehaviour
{
    private Animator animator;
    [SerializeField] public string instrument1 = "Cautery";
    [SerializeField] public string instrument2 = "Cautery";

    [SerializeField] public float time = 0;

    [SerializeField] public AnimationClip anim;
    [SerializeField] private GameObject canvas;

    [SerializeField] public bool SkinnedMesh = false;

    bool leftPrimaryPress = false;
    bool leftSecondaryPress = false;
    bool rightPrimaryPress = false;
    bool rightSecondaryPress = false;

    private bool checking = false;

    public void Start()
    {
        // Assuming the Animator is attached to the same GameObject
        animator = GetComponent<Animator>();
        StartAnimation();
        StopAnimation();
    }

    private void Update()
    {
        checkButton(out leftPrimaryPress, out leftSecondaryPress, out rightPrimaryPress, out rightSecondaryPress);

        if (checking)
        {
            ResumeAnimation();
        }

    }

    private void OnTriggerEnter(Collider other)
    {
        // Resume the animation if the collider is triggered again
        ResumeAnimation();
    }

    private void OnTriggerExit(Collider other)
    {
        // Stop the animation when the collider exits
        StopAnimation();
    }

    private void StartAnimation()
    {
        if (animator != null)
        {
            animator.Play(anim.name, 0, 0);
        }
    }

    public void StopAnimation()
    {
        if (animator != null)
        {
            // Stop the animation at the current frame
            animator.speed = 0f;
        }
    }

    public void ResumeAnimation()
    {
        if (rightSecondaryPress || leftSecondaryPress)
        {
            checking = false;
            // Resume the animation by setting the speed back to 1
            if (animator != null && time != 0)
            {
                if (animator.GetCurrentAnimatorStateInfo(0).normalizedTime < time)
                {
                    animator.speed = 1f;
                    //Debug.Log("Change instrument");
                }
                else
                    animator.speed = 1f;
            }
            else
            {
                animator.speed = 1f;
            }
        }
        else
        {
            canvas.GetComponent<Messages>().DisplayMessage(5);
            checking = true;
        }
    }

    public bool IsFinished()
    {
        if (animator != null)
        {
            // Check if the animation has finished
            return animator.GetCurrentAnimatorStateInfo(0).normalizedTime > 1;
        }
        return false;
    }

    private void checkButton(out bool leftPrimaryPress, out bool leftSecondaryPress, out bool rightPrimaryPress, out bool rightSecondaryPress)
    {
        UnityEngine.XR.InputDevice leftDevice;
        UnityEngine.XR.InputDevice rightDevice;

        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics leftControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
            InputDevices.GetDevicesWithCharacteristics(leftControllerCharacteristics, devices);

            if (devices.Count > 0)
            {
                leftDevice = devices[0];

                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //leftDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                leftPrimaryPress = primaryButtonValue;
                leftSecondaryPress = secondaryButtonValue;
            }
            else
            {
                leftPrimaryPress = false;
                leftSecondaryPress = false;
            }
        }
        {
            List<UnityEngine.XR.InputDevice> devices = new List<UnityEngine.XR.InputDevice>();
            InputDeviceCharacteristics rightControllerCharacteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;
            InputDevices.GetDevicesWithCharacteristics(rightControllerCharacteristics, devices);
            if (devices.Count > 0)
            {
                rightDevice = devices[0];

                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.gripButton, out bool primaryButtonValue);
                rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.triggerButton, out bool secondaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.primaryButton, out bool primaryButtonValue);
                //rightDevice.TryGetFeatureValue(UnityEngine.XR.CommonUsages.secondaryButton, out bool secondaryButtonValue);
                rightPrimaryPress = primaryButtonValue;
                rightSecondaryPress = secondaryButtonValue;
            }
            else
            {
                rightPrimaryPress = false;
                rightSecondaryPress = false;
            }

        }
    }
}
