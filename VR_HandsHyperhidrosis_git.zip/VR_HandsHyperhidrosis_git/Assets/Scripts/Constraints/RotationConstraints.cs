using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotationConstraints : MonoBehaviour
{
    public Vector3 shift = new Vector3(0f, 0f, 0f);
    private bool active = false;

    private Vector3 minRotation = new Vector3();
    private Vector3 maxRotation = new Vector3();

    private Vector3 initialRotation = new Vector3();

    private void Start()
    {
        initialRotation = transform.localRotation.eulerAngles;
    }

    void Update()
    {
        if (active)
        {
            ClampPositionAndRotation();
        }
    }

    void ClampPositionAndRotation()
    {
        // Clamp position delta
        Vector3 clampedPositionDelta = new Vector3(
            ClampAngle(transform.rotation.eulerAngles.x, minRotation.x, maxRotation.x),
            ClampAngle(transform.rotation.eulerAngles.y, minRotation.y, maxRotation.y),
            ClampAngle(transform.rotation.eulerAngles.z, minRotation.z, maxRotation.z));

        // Apply clamped position
        transform.rotation = Quaternion.Euler(clampedPositionDelta);
    }

    public void SetInitialRotation()
    {
        minRotation = transform.rotation.eulerAngles - shift;
        maxRotation = transform.rotation.eulerAngles + shift;

        active = true;
    }

    public void resetRotation()
    {
        transform.localRotation = Quaternion.Euler(initialRotation);
    }

    public void disable()
    {
        active = false;
    }

    private static float NormalizeAngle(float angle)
    {
        while (angle > 180f) angle -= 360f;
        while (angle < -180f) angle += 360f;
        return angle;
    }

    private static float ClampAngle(float angle, float min, float max)
    {
        angle = NormalizeAngle(angle);
        min = NormalizeAngle(min);
        max = NormalizeAngle(max);
        return Mathf.Clamp(angle, min, max);
    }
}