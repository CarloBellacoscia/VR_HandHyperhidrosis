using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookObject : MonoBehaviour
{
    [SerializeField] private GameObject objectToLookAt;

    //private Vector3 forward = new Vector3();
    private Vector3 initialRotation = new();
    private bool active = false;
    // Start is called before the first frame update
    void Start()
    {
        initialRotation = this.transform.rotation.eulerAngles;
    }

    // Update is called once per frame
    void Update()
    {
        if(active)
        {
            //Quaternion.LookRotation(forward, this.transform.up);
            //this.transform.LookAt(objectToLookAt.transform);
            //this.transform.parent.transform.GetChild(0).transform.LookAt(objectToLookAt.transform);
        }
    }

    public void activate()
    {
        //forward = objectToLookAt.transform.position - this.transform.position;
        //active = true;
        initialRotation = transform.rotation.eulerAngles;
        this.transform.LookAt(objectToLookAt.transform);
        //this.transform.parent.transform.GetChild(0).transform.LookAt(objectToLookAt.transform);
    }

    public void deactivate()
    {
        //active = false;
        //this.transform.rotation = Quaternion.Euler(initialRotation);
        //this.transform.localEulerAngles = initialRotation;
        //this.transform.parent.transform.GetChild(0).transform.localEulerAngles = initialRotation;
        //this.transform.LookAt(this.transform.position);
        this.transform.rotation = Quaternion.Euler(new Vector3(0,0,0));
    }
}
