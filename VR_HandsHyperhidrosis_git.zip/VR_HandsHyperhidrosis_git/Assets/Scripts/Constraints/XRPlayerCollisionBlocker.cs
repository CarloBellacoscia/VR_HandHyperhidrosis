using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class XRPlayerCollisionBlocker : MonoBehaviour
{
    public XRBaseController leftController;
    public XRBaseController rightController;
    public GameObject playerCamera;
    //private bool canMove = true;
    public Vector3 movementBoundsMin; // Minimum XYZ bounds
    public Vector3 movementBoundsMax; // Maximum XYZ bounds
    private List<Transform> list = new List<Transform>();
    private Transform handTransform;

    void Start()
    {
        // Check if the controllers are assigned
        if (leftController == null || rightController == null)
        {
            Debug.LogError("Please assign the controllers to the XRPlayerCollisionBlocker script.");
        }
        else if (leftController != null && rightController != null) 
        { 
            list.Add(leftController.transform);
            list.Add(rightController.transform);
            list.Add(playerCamera.transform);
        }
    }

    void Update()
    {
        foreach (Transform trans in list)
        {
            handTransform = trans;
            Vector3 newPosition = handTransform.position;

            // Clamp position within bounds
            newPosition.x = Mathf.Clamp(newPosition.x, movementBoundsMin.x, movementBoundsMax.x);
            newPosition.y = Mathf.Clamp(newPosition.y, movementBoundsMin.y, movementBoundsMax.y);
            newPosition.z = Mathf.Clamp(newPosition.z, movementBoundsMin.z, movementBoundsMax.z);

            handTransform.position = newPosition;
        }
    }
}

    /*
    void OnTriggerEnter(Collider other)
    {
        // Check if the trigger is with a wall
        if (other.gameObject.CompareTag("Wall"))
        {
            canMove = false;
            DisableControllerMovement();
        }
    }

    void OnTriggerExit(Collider other)
    {
        // Check if the trigger ending is with a wall
        if (other.gameObject.CompareTag("Wall"))
        {
            canMove = true;
            EnableControllerMovement();
        }
    }

    void DisableControllerMovement()
    {
        // Implement logic to disable movement
        if (leftController != null)
        {
            leftController.enableInputActions = false;
        }
        if (rightController != null)
        {
            rightController.enableInputActions = false;
        }
    }

    void EnableControllerMovement()
    {
        // Implement logic to enable movement
        if (leftController != null)
        {
            leftController.enableInputActions = true;
        }
        if (rightController != null)
        {
            rightController.enableInputActions = true;
        }
    }
    */

