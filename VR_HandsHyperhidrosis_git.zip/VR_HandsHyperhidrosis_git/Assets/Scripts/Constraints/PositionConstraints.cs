using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PositionConstraints : MonoBehaviour
{
    public Vector3 shift = new Vector3(0f, 0f, 0f);
    private bool active = false;
    private Vector3 minPosition = new Vector3();
    private Vector3 maxPosition = new Vector3();

    private Vector3 initialPosition = new Vector3();

    private void Start()
    {
        initialPosition = transform.position;
        //ClampPositionAndRotation();
    }

    void Update()
    {
        if (active)
        {
            ClampPositionAndRotation();
        }
    }

    void ClampPositionAndRotation()
    {
        // Clamp position delta
        Vector3 clampedPositionDelta = new Vector3(
            Mathf.Clamp(transform.position.x, minPosition.x, maxPosition.x),
            Mathf.Clamp(transform.position.y, minPosition.y, maxPosition.y),
            Mathf.Clamp(transform.position.z, minPosition.z, maxPosition.z));

        // Apply clamped position
        transform.position = clampedPositionDelta;
    }

    public void SetInitialPosition()
    {
        minPosition = transform.position - shift;
        maxPosition = transform.position + shift;
        ClampPositionAndRotation();

        //active = true;
    }

    public void resetPosition()
    {
        transform.position = initialPosition;
    }

    public void disable()
    {
        //active = false;
    }
}
